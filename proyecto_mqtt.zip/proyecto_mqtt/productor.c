#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mosquitto.h>

#define BROKER "localhost"
#define PORT 1883
#define TOPIC "universidad/mensaje"

void publicar_mensaje() {
    struct mosquitto *mosq;
    mosquitto_lib_init();

    // Crear cliente MQTT
    mosq = mosquitto_new(NULL, true, NULL);
    if (!mosq) {
        fprintf(stderr, "Error al crear cliente Mosquitto.\n");
        exit(1);
    }

    // Conectar al broker
    if (mosquitto_connect(mosq, BROKER, PORT, 60) != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Error al conectar con el broker.\n");
        exit(1);
    }

    // Mensaje a enviar
    char mensaje[512];
    snprintf(mensaje, sizeof(mensaje),
             "{\"matricula\":123456,\"nombre\":\"Juan\",\"apellido_paterno\":\"Perez\",\"apellido_materno\":\"Lopez\",\"materia\":\"Matemáticas\",\"calificacion\":\"A\",\"carrera\":\"Ingeniería\"}");

    // Publicar el mensaje
    if (mosquitto_publish(mosq, NULL, TOPIC, strlen(mensaje), mensaje, 0, false) != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Error al publicar el mensaje.\n");
        exit(1);
    }

    printf("Mensaje enviado: %s\n", mensaje);

    mosquitto_disconnect(mosq);
    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();
}

int main() {
    publicar_mensaje();
    return 0;
}
