#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mosquitto.h>
#include <mysql/mysql.h>

#define BROKER "localhost"
#define PORT 1883
#define TOPIC "universidad/mensaje"

// Función para guardar en la base de datos
void guardar_en_bd(const char *mensaje) {
    MYSQL *conn;
    MYSQL_STMT *stmt;
    MYSQL_BIND bind[7];
    int matricula;
    char nombre[50], apellido_paterno[50], apellido_materno[50];
    char materia[50], calificacion[10], carrera[50];

    // Conectar a la base de datos
    conn = mysql_init(NULL);
    if (!mysql_real_connect(conn, "localhost", "tu_usuario", "tu_contraseña", "mensajes", 0, NULL, 0)) {
        fprintf(stderr, "Error al conectar a la base de datos: %s\n", mysql_error(conn));
        exit(1);
    }

    // Parsear el mensaje JSON (de forma básica)
    sscanf(mensaje, "{\"matricula\":%d,\"nombre\":\"%49[^\"]\",\"apellido_paterno\":\"%49[^\"]\",\"apellido_materno\":\"%49[^\"]\",\"materia\":\"%49[^\"]\",\"calificacion\":\"%9[^\"]\",\"carrera\":\"%49[^\"]\"}",
           &matricula, nombre, apellido_paterno, apellido_materno, materia, calificacion, carrera);

    // Preparar la consulta
    stmt = mysql_stmt_init(conn);
    const char *query = "INSERT INTO datos (matricula, nombre, apellido_paterno, apellido_materno, materia, calificacion, carrera) VALUES (?, ?, ?, ?, ?, ?, ?)";
    mysql_stmt_prepare(stmt, query, strlen(query));

    // Enlazar los datos
    memset(bind, 0, sizeof(bind));
    bind[0].buffer_type = MYSQL_TYPE_LONG;
    bind[0].buffer = &matricula;
    bind[1].buffer_type = MYSQL_TYPE_STRING;
    bind[1].buffer = nombre;
    bind[1].buffer_length = strlen(nombre);
    bind[2].buffer_type = MYSQL_TYPE_STRING;
    bind[2].buffer = apellido_paterno;
    bind[2].buffer_length = strlen(apellido_paterno);
    bind[3].buffer_type = MYSQL_TYPE_STRING;
    bind[3].buffer = apellido_materno;
    bind[3].buffer_length = strlen(apellido_materno);
    bind[4].buffer_type = MYSQL_TYPE_STRING;
    bind[4].buffer = materia;
    bind[4].buffer_length = strlen(materia);
    bind[5].buffer_type = MYSQL_TYPE_STRING;
    bind[5].buffer = calificacion;
    bind[5].buffer_length = strlen(calificacion);
    bind[6].buffer_type = MYSQL_TYPE_STRING;
    bind[6].buffer = carrera;
    bind[6].buffer_length = strlen(carrera);

    mysql_stmt_bind_param(stmt, bind);
    mysql_stmt_execute(stmt);

    printf("Datos guardados en la base de datos.\n");

    mysql_stmt_close(stmt);
    mysql_close(conn);
}

// Callback al recibir un mensaje
void on_message(struct mosquitto *mosq, void *userdata, const struct mosquitto_message *msg) {
    printf("Mensaje recibido: %s\n", (char *)msg->payload);
    guardar_en_bd((char *)msg->payload);
}

int main() {
    struct mosquitto *mosq;

    mosquitto_lib_init();

    // Crear cliente MQTT
    mosq = mosquitto_new(NULL, true, NULL);
    if (!mosq) {
        fprintf(stderr, "Error al crear cliente Mosquitto.\n");
        exit(1);
    }

    // Conectar al broker
    if (mosquitto_connect(mosq, BROKER, PORT, 60) != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Error al conectar con el broker.\n");
        exit(1);
    }

    // Configurar callback
    mosquitto_message_callback_set(mosq, on_message);

    // Suscribirse al tema
    mosquitto_subscribe(mosq, NULL, TOPIC, 0);

    printf("Esperando mensajes...\n");
    mosquitto_loop_forever(mosq, -1, 1);

    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    return 0;
}
