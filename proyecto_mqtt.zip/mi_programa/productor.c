#include <stdio.h>
#include <mosquitto.h>
#include <string.h>

#define BROKER "localhost"
#define PORT 1883
#define TOPIC "mi_base/mensajes"

int main() {
    struct mosquitto *mosq;
    char mensaje[256];
    int matricula;
    char nombre[50], apellido_paterno[50], apellido_materno[50];
    char materia[50], calificacion[3], carrera[50];

    // Inicialización de Mosquitto
    mosquitto_lib_init();
    mosq = mosquitto_new(NULL, true, NULL);

    if (!mosq) {
        printf("Error al inicializar Mosquitto\n");
        return 1;
    }

    if (mosquitto_connect(mosq, BROKER, PORT, 60) != MOSQ_ERR_SUCCESS) {
        printf("Error al conectar al broker\n");
        return 1;
    }

    // Solicitar datos
    printf("Ingrese los siguientes datos:\n");
    printf("Matricula: ");
    scanf("%d", &matricula);
    printf("Nombre: ");
    scanf("%s", nombre);
    printf("Apellido Paterno: ");
    scanf("%s", apellido_paterno);
    printf("Apellido Materno: ");
    scanf("%s", apellido_materno);
    printf("Materia: ");
    scanf("%s", materia);
    printf("Calificacion: ");
    scanf("%s", calificacion);
    printf("Carrera: ");
    scanf("%s", carrera);

    // Formatear mensaje
    snprintf(mensaje, sizeof(mensaje),
             "%d|%s|%s|%s|%s|%s|%s",
             matricula, nombre, apellido_paterno, apellido_materno,
             materia, calificacion, carrera);

    // Publicar mensaje
    if (mosquitto_publish(mosq, NULL, TOPIC, strlen(mensaje), mensaje, 0, false) != MOSQ_ERR_SUCCESS) {
        printf("Error al publicar mensaje\n");
        return 1;
    }

    printf("Mensaje publicado: %s\n", mensaje);

    // Finalización
    mosquitto_disconnect(mosq);
    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    return 0;
}
