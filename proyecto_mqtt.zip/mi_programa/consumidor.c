#include <stdio.h>
#include <mosquitto.h>
#include <mysql/mysql.h>
#include <string.h>

#define BROKER "localhost"
#define PORT 1883
#define TOPIC "mi_base/mensajes"

void guardar_en_bd(const char *mensaje) {
    MYSQL *conn;

    char *server = "localhost";
    char *user = "root";
    char *password = "nueva_contraseña";  // Coloca tu contraseña aquí
    char *database = "mi_base";

    // Conectar a la base de datos
    conn = mysql_init(NULL);
    if (!mysql_real_connect(conn, server, user, password, database, 0, NULL, 0)) {
        fprintf(stderr, "Error al conectar a la base de datos: %s\n", mysql_error(conn));
        return;
    }

    // Separar mensaje
    int matricula;
    char nombre[50], apellido_paterno[50], apellido_materno[50];
    char materia[50], calificacion[3], carrera[50];

    sscanf(mensaje, "%d|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]|%[^|]",
           &matricula, nombre, apellido_paterno, apellido_materno,
           materia, calificacion, carrera);

    // Insertar datos
    char query[512];
    snprintf(query, sizeof(query),
             "INSERT INTO mensajes (matricula, nombre, apellido_paterno, apellido_materno, materia, calificacion, carrera) "
             "VALUES (%d, '%s', '%s', '%s', '%s', '%s', '%s')",
             matricula, nombre, apellido_paterno, apellido_materno, materia, calificacion, carrera);

    if (mysql_query(conn, query)) {
        fprintf(stderr, "Error al insertar datos: %s\n", mysql_error(conn));
    } else {
        printf("Datos guardados en la base de datos\n");
    }

    mysql_close(conn);
}

void on_message(struct mosquitto *mosq, void *obj, const struct mosquitto_message *msg) {
    if (msg->payloadlen) {
        printf("Mensaje recibido: %s\n", (char *)msg->payload);
        guardar_en_bd((char *)msg->payload);
    } else {
        printf("Mensaje vacío recibido\n");
    }
}

int main() {
    struct mosquitto *mosq;

    // Inicialización de Mosquitto
    mosquitto_lib_init();
    mosq = mosquitto_new(NULL, true, NULL);

    if (!mosq) {
        printf("Error al inicializar Mosquitto\n");
        return 1;
    }

    if (mosquitto_connect(mosq, BROKER, PORT, 60) != MOSQ_ERR_SUCCESS) {
        printf("Error al conectar al broker\n");
        return 1;
    }

    mosquitto_message_callback_set(mosq, on_message);

    mosquitto_subscribe(mosq, NULL, TOPIC, 0);

    printf("Esperando mensajes...\n");
    mosquitto_loop_forever(mosq, -1, 1);

    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    return 0;
}
